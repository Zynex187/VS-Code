const search = document.querySelector('.search input');
const chats = document.querySelectorAll('.chats li');

search.addEventListener('input', function () {
  const text = search.value.toLowerCase();
  for (const chat of chats) {
    const name = chat.querySelector('h3').textContent.toLowerCase();
    if (name.includes(text)) {
      chat.style.display = '';
    } else {
      chat.style.display = 'none';
    }
  }
});

const input = document.querySelector('.composer input');
const list = document.querySelector('.messages .list');

input.addEventListener('keydown', function (event) {
  if (event.key === 'Enter' && input.value !== '') {
    const message = document.createElement('article');
    message.className = 'message out';
    const text = document.createElement('p');
    text.textContent = input.value;
    message.append(text);
    list.append(message);
    input.value = '';
  }
});